def make_url():
    url = "https://server.qdev.nayasinghania.com"
    # url = "https://server.qdev.nayasinghania.com"
    return url
